<script setup>
</script>

<template>
  <div id="app">
    <RouterView />
  </div>
</template>

<style>
html, body, #app {
  margin: 0;
  padding: 0;
  height: 100%;
  font-family: system-ui, -apple-system, sans-serif;
  background: #ffffff;
}
</style>
